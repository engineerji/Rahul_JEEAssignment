package servletspackage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employee;

/**
 * Servlet implementation class ValidationServlet
 */
public class ValidationServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String userName= req.getParameter("username");
		String password=req.getParameter("password");
		String rePassword=req.getParameter("repassword");
		int age=Integer.parseInt(req.getParameter("age"));
		String[] technologies=req.getParameterValues("technology");
		String city= req.getParameter("city");
		String gender = req.getParameter("gender");
		int val = Integer.parseInt(req.getParameter("workexp"));
		req.getSession().setAttribute("employeeusername", userName);
		RequestDispatcher requestDispatcher = req.getRequestDispatcher("Information.jsp");
		Employee employee = new Employee(userName,password,age,technologies,city,gender,val);
		
		System.out.println(employee.getUserName()+" "+password+" "+rePassword+" "+age+" "+city+" "+gender+" "+val+"\n");
		for(String st:technologies) {
			System.out.println(st+" ");
		}
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		if(userName.length()<3 || !(userName.matches( "[A-Z][a-zA-Z]*" ))) {
			out.println("Invalid Name");
			System.out.println("invalid name");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='index.html'>Login</a>");
		}
		else if(!password.equals(rePassword)) {
			out.print("Password and Repeat Password are not same.");
			System.out.println("wrong password");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='index.html'>Login</a>");
		}
		else if(age<18 || age>60) {
			out.print("Invalid age. Age should be between 18 and 60");
			System.out.println("Wrong age");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='index.html'>Login</a>");
		}
		else {
			out.println("<table>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Name:");
			out.println("</td>");
			out.println("<td>");
			out.println(employee.getUserName());
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Age:");
			out.println("</td>");
			out.println("<td>");
			out.println(employee.getAge());
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Technologies Known:");
			out.println("</td>");
			out.println("<td>");
			String emp[]=employee.getTechnologies();
			for(String st:emp) {
				out.print(st+" ");
			}
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("City:");
			out.println("</td>");
			out.println("<td>");
			out.println(employee.getCity());
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Gender:");
			out.println("</td>");
			out.println("<td>");
			out.println(employee.getGender());
			out.println("</td>");
			out.println("</tr>");
			out.println("<tr>");
			out.println("<td>");
			out.println("Work Experience:");
			out.println("</td>");
			out.println("<td>");
			out.println(employee.getWorkExp());
			out.println("</td>");
			out.println("</tr>");
			out.println("</table>");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='index.html'>Login</a>");
			out.println("</br>");
			out.println("Project Category");
			if(emp.length>=2) {
				if(emp[0].equals("Java") && emp[1].equals("Angular")) {
					out.println("</br>");
					out.println("Java Full Stack Project");
				}
				else if(emp[0].equals("python") && emp[1].equals("R")) {
					out.println("</br>");
					out.println("AI Project");
				}
			}
			else if(emp[0].equals("Oracle")) {
				out.println("</br>");
				out.println("DBA Project");
			}
			else if(emp[0].equals("Juniper")) {
				out.println("</br>");
				out.println("Network Admin");
			}
		}
	}
	

}
