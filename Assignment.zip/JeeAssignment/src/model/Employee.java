package model;

import java.util.Arrays;

public class Employee {
	private String userName;
	private String password;
	private int age;
	private String technologies[];
	private String city;
	private String gender;
	private int workExp;
	
	public Employee(String userName, String password, int age, String[] technologies, String city, String gender,
			int workExp) {
		super();
		this.userName = userName;
		this.password = password;
		this.age = age;
		this.technologies = technologies;
		this.city = city;
		this.gender = gender;
		this.workExp = workExp;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getTechnologies() {
		return technologies;
	}
	public void setTechnologies(String[] technologies) {
		this.technologies = technologies;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getWorkExp() {
		return workExp;
	}
	public void setWorkExp(int workExp) {
		this.workExp = workExp;
	}
	@Override
	public String toString() {
		return "Employee [userName=" + userName + ", password=" + password + ", age=" + age + ", technologies="
				+ Arrays.toString(technologies) + ", city=" + city + ", gender=" + gender + ", workExp=" + workExp
				+ "]";
	}
	

}
