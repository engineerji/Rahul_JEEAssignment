package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidationServlet
 */
public class ValidationServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName= req.getParameter("username");
		String password=req.getParameter("password");
		String rePassword=req.getParameter("repassword");
		int age=Integer.parseInt(req.getParameter("age"));
		String[] technologies=req.getParameterValues("technology");
		String city= req.getParameter("city");
		String gender = req.getParameter("gender");
		int val = Integer.parseInt(req.getParameter("workexp"));
		PrintWriter out = resp.getWriter();
		out.println("<h1>Error Page</h1>");
		System.out.println(userName+" "+password+" "+rePassword+" "+age+" "+city+" "+gender+" "+val+"\n");
		if(userName.length()<3 || !(userName.matches( "[A-Z][a-zA-Z]*" ))) {
			out.println("Invalid Name");
			System.out.println("invalid name");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='RegistrationPage.html'>Login</a>");
		}
		else if(!password.equals(rePassword)) {
			out.print("Password and Repeat Password are not same.");
			System.out.println("wrong password");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='RegistrationPage.html'>Login</a>");
		}
		else if(age<18 || age>60) {
			out.print("Invalid age. Age should be between 18 and 60");
			System.out.println("Wrong age");
			out.println("</br>");
			out.println("Login Again");
			out.println("</br>");
			out.println("<a href='RegistrationPage.html'>Login</a>");
		}
		else {
			RequestDispatcher requestdis = req.getRequestDispatcher("ResponseServlet");
			requestdis.forward(req, resp);
			
			}
		
	}
	

}
