package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Employee;
import service.ProjectService;

/**
 * Servlet implementation class ResponseServlet
 */
public class ResponseServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("<h2>Render the User Data</h2>");
		String userName= req.getParameter("username");
		String password=req.getParameter("password");
		String rePassword=req.getParameter("repassword");
		int age=Integer.parseInt(req.getParameter("age"));
		String[] technologies=req.getParameterValues("technology");
		String city= req.getParameter("city");
		String gender = req.getParameter("gender");
		int val = Integer.parseInt(req.getParameter("workexp"));
		Employee employee = new Employee(userName,password,age,technologies,city,gender,val);
		
		ProjectService serve= new ProjectService();
		String project=serve.assignProject(technologies);
		
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>");
		out.println("Name:");
		out.println("</td>");
		out.println("<td>");
		out.println(employee.getUserName());
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>");
		out.println("Age:");
		out.println("</td>");
		out.println("<td>");
		out.println(employee.getAge());
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>");
		out.println("Technologies Known:");
		out.println("</td>");
		out.println("<td>");
		String emp[]=employee.getTechnologies();
		for(String st:emp) {
			out.print(st+" ");
		}
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>");
		out.println("City:");
		out.println("</td>");
		out.println("<td>");
		out.println(employee.getCity());
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>");
		out.println("Gender:");
		out.println("</td>");
		out.println("<td>");
		out.println(employee.getGender());
		out.println("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>");
		out.println("Work Experience:");
		out.println("</td>");
		out.println("<td>");
		out.println(employee.getWorkExp());
		out.println("</td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("Project Category: "+project);
		out.print("</br>");
		out.print("</br>");
		out.print("</br>");
		out.println("Login Again");
		out.println("</br>");
		out.println("<a href='RegistrationPage.html'>Login</a>");
	}
	

}
