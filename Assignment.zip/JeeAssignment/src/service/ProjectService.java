package service;

public class ProjectService {
	public String assignProject(String tech[]) {
		String project="";
		if(tech.length>=2){
			if(tech[0].equals("Java") && tech[1].equals("Angular")) {
				project="Java Full Stack Project";
			}
			else if(tech[0].equals("Python")&&tech[1].equals("R")) {
				project="AI Project";
			}
			else {
				project = "No project Assigned";
			}
		}
		else if(tech[0].equals("Oracle")) {
			project="DBA Project";
		}
		else if(tech[0].equals("Juniper")) {
			
		}
		else {
			project = "No project Assigned";
		}
		return project;
	}
}
